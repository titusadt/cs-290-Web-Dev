#ifndef STATE_H
#define STATE_H
#include<iostream>

using namespace std;

struct State{
   int square_size;
   int player_x;
   int player_y;
   int  player_gold;
   int arrows;

};
#endif

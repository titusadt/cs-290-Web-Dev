#ifndef MONKEY_H
#define MONKEY_H
#include<iostream>
#include<string>
#include"animal.h"

using namespace std;

class Monkey: public Animal{
 
   public:
      Monkey();
      Monkey(int);
};




#endif

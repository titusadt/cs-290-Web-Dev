#ifndef MEERKAT_H
#define MEERKAT_H
#include<iostream>
#include<string>
#include"animal.h"

using namespace std;

class Meerkat: public Animal{
 
   public:
      Meerkat();
      Meerkat(int);
};




#endif

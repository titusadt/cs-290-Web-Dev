#ifndef LIST_NODE_H
#define LIST_NODE_H
#include<iostream>

using namespace std;

class Linked_List_Node{
   public:
      int val;
      Linked_List_Node *next;
};
#endif

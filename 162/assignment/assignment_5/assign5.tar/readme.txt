In my push_front function the TA Fauzi Kliman said it was alright for me to call my insert function in my push_front function and just use that for the function.
 tried to create my isprime function but i could not finish it so i commented it out and I do not call it in  main

#include<iostream>
#include"rectangle.h"

using namespace std;

class Square : public Rectangle{
   public:
      Square(float, float);
 

};

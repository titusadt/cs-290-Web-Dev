#ifndef SHAPE_H
#define SHAPE_H
#include<iostream>
#include<string>

using namespace std;

class Shape{
   protected:
      string name;
      string colour;
   public:
      string get_name()const;
      void set_name(string);
      string get_colour()const;
      void set_colour(string);
      int area();
      bool &operator >(const Shape &s2);
      bool &operator <(const Shape &s2);
      virtual void shape_area();
      void print_area(Shape &);
};
#endif

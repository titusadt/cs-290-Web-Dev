#include<iostream>
#include<string>
#include"shape.h"
#include"rectangle.h"
#include"circle.h"
#include"square.h"

using namespace std;

int main(){




return 0;
}


#include<iostream>
#include"rectangle.h"
#include"square.h"

using namespace std;

Square::Square(float side) : Rectangle(side, side){


}
